#!/bin/bash

#GUROBI 9.5.1 
# prepend_path("PATH","/local/software/gurobi/9.5.1/gurobi051/linux64/bin")
export PATH=/local/software/gurobi/9.5.1/gurobi951/linux64/bin:${PATH}
# setenv("GUROBI_HOME","/local/software/gurobi/9.5.1")
export GUROBI_HOME=/local/software/gurobi/9.5.1
# setenv("GRB_LICENSE_FILE","/local/software/gurobi/9.5.1/gurobi.lic")
export GRB_LICENSE_FILE=/local/software/gurobi/9.5.1/gurobi.lic
# prepend_path("LD_LIBRARY_PATH","/local/software/gurobi/9.5.1/gurobi051/linux64/lib")
export LD_LIBRARY_PATH=/local/software/gurobi/9.5.1/gurobi951/linux64/lib:${LD_LIBRARY_PATH}
# prepend_path("GRB_INC_PATH","/local/software/gurobi/9.5.1/gurobi051/linux64/include")
export GRB_INC_PATH=/local/software/gurobi/9.5.1/gurobi951/linux64/include:${GRB_INC_PATH}
# prepend_path("GRB_LIB_PATH","/local/software/gurobi/9.5.1/gurobi051/linux64/lib")
export GRB_LIB_PATH=/local/software/gurobi/9.5.1/gurobi951/linux64/lib:${GRB_LIB_PATH}

./BPPS $HOME/BPP_INST/Waescher/Waescher_TEST0055B.txt ./param_test_BPP-non-IRUP-2exp44.txt 20230629 1 1 1

